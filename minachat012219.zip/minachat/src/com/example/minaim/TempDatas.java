package com.example.minaim;

public class TempDatas {
	
	public static String registrationID="";
}
