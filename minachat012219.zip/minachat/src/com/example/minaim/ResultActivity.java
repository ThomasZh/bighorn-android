package com.example.minaim;

import android.app.Activity;
import android.os.Bundle;
import net.younguard.bighorn.R;

public class ResultActivity extends BaseActivity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

}
