package com.example.minaim;

import android.app.Application;

public class mApplication extends Application {
	public boolean isAlive=true;

}
